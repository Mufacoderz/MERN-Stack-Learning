console.info("hello world")

//jalankan node js di terminal dgn ketik node namafile